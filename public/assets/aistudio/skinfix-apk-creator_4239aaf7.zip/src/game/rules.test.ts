import test from 'node:test';
import assert from 'node:assert/strict';
import { GameEngine } from './engine';
import { UNIT_BLUEPRINTS, STARTER_UNITS } from '../data/units';

test('Starter units include Supplier, Engineer, Machine Gunner, Transport, and core troops', () => {
  assert.ok(STARTER_UNITS.includes('P'), 'Supplier should be in starter units');
  assert.ok(STARTER_UNITS.includes('N'), 'Engineer should be in starter units');
  assert.ok(STARTER_UNITS.includes('Z'), 'Machine Gunner should be in starter units');
  assert.ok(STARTER_UNITS.includes('AT'), 'Assault Transport should be in starter units');
  assert.ok(STARTER_UNITS.includes('R'), 'Riflemen should be in starter units');
  assert.ok(STARTER_UNITS.includes('B'), 'Battle Tank should be in starter units');
});

test('GameEngine initializes 15x15 board with 2 factions and HQs', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 15,
    playersCount: 2,
    humanFactions: [0],
  });

  assert.equal(engine.N, 15);
  assert.equal(engine.NP, 2);
  assert.equal(engine.alive[0], true);
  assert.equal(engine.alive[1], true);

  const playerHq = engine.U.find((u) => u.t === 'H' && u.o === 0);
  const enemyHq = engine.U.find((u) => u.t === 'H' && u.o === 1);
  assert.ok(playerHq, 'Player HQ must exist');
  assert.ok(enemyHq, 'Enemy HQ must exist');
});

test('Carry unit logic: Transport can embark adjacent friendly infantry and eject safely', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
  });

  const transport = engine.addUnit('AT', 0, 3, 3);
  const infantry = engine.addUnit('R', 0, 3, 4);

  assert.equal(engine.U.includes(infantry), true);
  assert.equal(transport.cargo, null);

  // Load infantry
  transport.cargo = infantry;
  engine.U = engine.U.filter((u) => u !== infantry);

  assert.equal(engine.U.includes(infantry), false);
  assert.equal(transport.cargo.t, 'R');

  // Unload cargo
  const unloadTarget = { x: 3, y: 4 };
  const cargo = transport.cargo;
  cargo.x = cargo.rx = unloadTarget.x;
  cargo.y = cargo.ry = unloadTarget.y;
  engine.U.push(cargo);
  transport.cargo = null;

  assert.equal(engine.U.includes(cargo), true);
  assert.equal(cargo.x, 3);
  assert.equal(cargo.y, 4);
});

test('Healer logic: Field Medic restores HP to damaged infantry', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
  });

  const wounded = engine.addUnit('R', 0, 2, 2);
  wounded.hp = 1; // damaged
  assert.equal(wounded.hp, 1);

  // Field triage restores 3 HP up to maxHp
  const healAmount = 3;
  wounded.hp = Math.min(wounded.maxHp, wounded.hp + healAmount);
  assert.equal(wounded.hp, wounded.maxHp);
});

test('Mobile Factory Spawner: can construct units on the field', () => {
  const bp = UNIT_BLUEPRINTS.FC;
  assert.ok(bp, 'FC blueprint exists');
  assert.equal(bp.isSpawner, true);
  assert.equal(bp.c, 58, 'Factory Crawler has high cost');
  assert.ok(bp.ab.some((ab) => ab.f.includes('sp')), 'Has spawner ability flag');
});

test('Advanced Units exist in blueprints: HF, IJ, SB, NS, SR', () => {
  assert.ok(UNIT_BLUEPRINTS.HF, 'Heavy Flak Battery blueprint exists');
  assert.equal(UNIT_BLUEPRINTS.HF.n, 'Heavy Flak Battery');
  assert.ok(UNIT_BLUEPRINTS.IJ, 'Interceptor Jet blueprint exists');
  assert.equal(UNIT_BLUEPRINTS.IJ.n, 'Interceptor Jet');
  assert.ok(UNIT_BLUEPRINTS.SB, 'Stealth Bomber blueprint exists');
  assert.ok(UNIT_BLUEPRINTS.NS, 'Nanite Swarm Hive blueprint exists');
  assert.ok(UNIT_BLUEPRINTS.SR, 'Siege Ram Carrier blueprint exists');
});

test('Difficulty levels: Normal, Smarty, Sweat, and Tryhard are supported', () => {
  const engine = new GameEngine();

  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
    difficulty: 'normal',
  });
  assert.equal(engine.difficulty, 'normal');
  assert.equal(engine.isIntermediateOrHigher(), false);
  assert.equal(engine.isHighDifficulty(), false);

  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
    difficulty: 'smarty',
  });
  assert.equal(engine.difficulty, 'smarty');
  assert.equal(engine.isIntermediateOrHigher(), true);
  assert.equal(engine.isHighDifficulty(), false);

  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
    difficulty: 'sweat',
  });
  assert.equal(engine.difficulty, 'sweat');
  assert.equal(engine.isIntermediateOrHigher(), true);
  assert.equal(engine.isHighDifficulty(), true);

  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
    difficulty: 'tryhard',
  });
  assert.equal(engine.difficulty, 'tryhard');
  assert.equal(engine.isIntermediateOrHigher(), true);
  assert.equal(engine.isHighDifficulty(), true);
  assert.equal(engine.isTryhard(), true);
});

test('Tactical AI: Bot recruits and deploys custom units per difficulty', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 12,
    playersCount: 2,
    humanFactions: [0],
    difficulty: 'tryhard',
    startingGold: [50, 100],
  });

  // Verify tryhard auto deploy populates advanced units
  engine.botAutoDeploy(1, 4);
  const botUnits = engine.U.filter((u) => u.o === 1 && !UNIT_BLUEPRINTS[u.t].bl);
  assert.ok(botUnits.length > 0, 'Bot should deploy units');
});
