import React, { useState } from 'react';
import { GameEngineInitParams } from '../game/engine';
import { BotDifficulty } from '../types/game';
import { SKINS_CATALOG, FACTION_NAMES, FACTION_COLORS } from '../data/skins';
import {
  Swords,
  Globe,
  Bot,
  Users,
  Play,
  RotateCcw,
  Sparkles,
  Shield,
  Layers,
  Palette,
  Check,
} from 'lucide-react';

interface SkirmishGeneratorProps {
  onStartMatch: (params: GameEngineInitParams) => void;
}

export const SkirmishGenerator: React.FC<SkirmishGeneratorProps> = ({ onStartMatch }) => {
  const [selectedPreset, setSelectedPreset] = useState<number>(0);
  const [startingGold, setStartingGold] = useState<number>(24);
  const [fogOfWar, setFogOfWar] = useState<boolean>(true);
  const [autoDeploy, setAutoDeploy] = useState<boolean>(true);
  const [difficulty, setDifficulty] = useState<BotDifficulty>('smarty');
  const [customSize, setCustomSize] = useState<number | null>(null);
  const [baseLayout, setBaseLayout] = useState<'standard' | 'diagonal' | 'flank' | 'asymmetric' | 'corners' | 'random'>('random');
  const [botSkins, setBotSkins] = useState<Record<number, string>>({
    1: 'skin_ww2_germany',
    2: 'skin_imperial_japan',
    3: 'skin_girls_und_panzer',
    0: 'skin_toy_soldiers',
  });

  const PRESETS = [
    {
      id: 0,
      title: 'Compact Strike (10x10)',
      desc: 'Fast, intense close-quarters skirmish with rapid engagements on a tight 10x10 grid.',
      mapSize: 10,
      players: 2,
      humans: [0],
      icon: Swords,
    },
    {
      id: 1,
      title: 'River Delta Crossings (14x14)',
      desc: 'Tactical water crossing with bridges, canal defiles, and amphibious hovercraft routes.',
      mapSize: 14,
      players: 2,
      humans: [0],
      icon: Globe,
    },
    {
      id: 2,
      title: 'Tactical Skirmish vs AI (15x15)',
      desc: '1v1 combined-arms tactical battle against computer AI on a standard 15x15 sector.',
      mapSize: 15,
      players: 2,
      humans: [0],
      icon: Swords,
    },
    {
      id: 3,
      title: 'Sunken Archipelago (18x18)',
      desc: 'Flooded island chain with scattered outposts. Perfect for Hovercraft, Gunships, and Artillery.',
      mapSize: 18,
      players: 2,
      humans: [0],
      icon: Globe,
    },
    {
      id: 4,
      title: 'Frontline War (20x20)',
      desc: 'Expanded 20x20 battlefield with wide flanking routes, off-center outposts, and river crossings.',
      mapSize: 20,
      players: 2,
      humans: [0],
      icon: Globe,
    },
    {
      id: 5,
      title: 'Tri-War Citadel (24x24)',
      desc: '3-way superpower conflict on an expansive 24x24 fortress map with multiple forward barracks.',
      mapSize: 24,
      players: 3,
      humans: [0],
      icon: Globe,
    },
    {
      id: 6,
      title: 'Two Players (Pass & Play)',
      desc: '1v1 local multiplayer on one device with turn cover privacy.',
      mapSize: 15,
      players: 2,
      humans: [0, 1],
      icon: Users,
    },
    {
      id: 7,
      title: 'Bot vs Bot Simulation',
      desc: 'Spectate two autonomous AI commanders fighting for victory in real-time. Zero manual deployment.',
      mapSize: 15,
      players: 2,
      humans: [],
      icon: Bot,
    },
    {
      id: 8,
      title: 'Grand War: You vs 3 AI Powers (30x30)',
      desc: 'Massive 30x30 theater with 4 corner HQs and multiple staging barracks across 4 quadrants.',
      mapSize: 30,
      players: 4,
      humans: [0],
      icon: Globe,
    },
    {
      id: 9,
      title: '4-Way Grand War (Spectate)',
      desc: 'Watch four autonomous AI superpowers clash across a 30x30 theater. Instant battle, zero setup.',
      mapSize: 30,
      players: 4,
      humans: [],
      icon: Bot,
    },
    {
      id: 10,
      title: 'Grand War: 4 Players Local',
      desc: '4-player hotseat conflict on one shared device.',
      mapSize: 30,
      players: 4,
      humans: [0, 1, 2, 3],
      icon: Users,
    },
  ];

  const currentPreset = PRESETS[selectedPreset] || PRESETS[0];
  const actualSize = customSize !== null ? customSize : currentPreset.mapSize;
  const isSpectate = currentPreset.humans.length === 0;

  const handleLaunch = () => {
    const p = PRESETS[selectedPreset] || PRESETS[0];
    const isBotSim = p.humans.length === 0;
    const finalSize = customSize !== null ? customSize : p.mapSize;
    const layout = baseLayout === 'random' ? undefined : (baseLayout as any);

    onStartMatch({
      mapSize: finalSize,
      playersCount: p.players,
      humanFactions: p.humans,
      startingGold: Array(p.players).fill(finalSize >= 20 ? startingGold * 2 : startingGold),
      autoDeploy: isBotSim || autoDeploy,
      fogOfWar: isBotSim ? false : fogOfWar,
      difficulty,
      baseLayout: layout,
      factionSkins: botSkins,
    });
  };

  const [filterCategory, setFilterCategory] = useState<'all' | 'vs_ai' | 'spectate' | 'local'>('all');
  const visiblePresets = PRESETS.filter((p) => {
    if (filterCategory === 'all') return true;
    if (filterCategory === 'vs_ai') return p.humans.length === 1;
    if (filterCategory === 'spectate') return p.humans.length === 0;
    if (filterCategory === 'local') return p.humans.length > 1;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      {/* Sandbox Header */}
      <div className="bg-gradient-to-r from-[#141b20] to-[#101417] border border-[#232c32] rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
            <Shield className="w-4 h-4" />
            <span>TACTICAL WAR ROOM SANDBOX</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-100 tracking-tight">
            Custom Skirmish Generator
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-xl">
            Choose single-player vs AI, local pass-and-play, or relax and spectate full-scale autonomous AI bot wars.
          </p>
        </div>

        <button
          onClick={handleLaunch}
          className="py-3 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-950/30 shrink-0 transition-all"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>Launch Selected Mode</span>
        </button>
      </div>

      {/* Preset Filters */}
      <div className="flex items-center gap-1.5 p-1 bg-[#0c1012] rounded-xl border border-[#232c32] text-xs font-mono overflow-x-auto">
        <button
          onClick={() => setFilterCategory('all')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
            filterCategory === 'all'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Modes ({PRESETS.length})
        </button>
        <button
          onClick={() => setFilterCategory('vs_ai')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            filterCategory === 'vs_ai'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Swords className="w-3.5 h-3.5" />
          <span>You vs AI Bots</span>
        </button>
        <button
          onClick={() => setFilterCategory('spectate')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            filterCategory === 'spectate'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>Bot vs Bot (Spectate)</span>
        </button>
        <button
          onClick={() => setFilterCategory('local')}
          className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            filterCategory === 'local'
              ? 'bg-amber-500 text-slate-950 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Pass & Play (1 Device)</span>
        </button>
      </div>

      {/* Presets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {visiblePresets.map((preset) => {
          const Icon = preset.icon;
          const isSelected = selectedPreset === preset.id;
          const badge =
            preset.id === 0
              ? '⭐ Recommended Starter'
              : preset.id === 2
              ? '⚡ Instant AI Spectate'
              : preset.id === 3
              ? '🔥 Epic 4-Way War'
              : preset.id === 4
              ? '👑 4-Way AI Showdown'
              : null;

          return (
            <div
              key={preset.id}
              onClick={() => setSelectedPreset(preset.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'border-amber-400 bg-[#161e22] shadow-lg shadow-amber-950/20'
                  : 'border-[#232c32] bg-[#111619] hover:border-[#384650]'
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-[#1b2328] text-slate-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-200 text-sm">{preset.title}</h3>
                    <span className="text-[11px] font-mono text-slate-400">
                      Grid {preset.mapSize}x{preset.mapSize} · {preset.players} Factions
                    </span>
                  </div>
                </div>
                {badge && (
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 whitespace-nowrap">
                    {badge}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed pl-12">{preset.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Custom Match Parameters */}
      <div className="bg-[#12171a] p-5 rounded-xl border border-[#232c32] space-y-4">
        <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400">
          Match Parameters & Difficulty
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Starting Gold */}
          <div className="space-y-1.5 p-3 bg-[#0c1012] rounded-lg border border-[#232c32] flex flex-col justify-between">
            <div>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300">Deployment Budget</span>
                <span className="text-amber-400 font-bold">{startingGold} Gold</span>
              </div>
              <input
                type="range"
                min={16}
                max={64}
                step={4}
                value={startingGold}
                onChange={(e) => setStartingGold(parseInt(e.target.value, 10))}
                className="w-full accent-amber-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer mt-2"
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-500 pt-1">
              <span>16 (Scarcity)</span>
              <span>64 (Blitz)</span>
            </div>
          </div>

          {/* AI Difficulty (Normal, Smarty, Sweat, Tryhard) */}
          <div className="flex flex-col justify-between p-3 bg-[#0c1012] rounded-lg border border-[#232c32]">
            <div>
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-slate-200 font-mono">AI Intelligence</div>
                <span
                  className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                    difficulty === 'tryhard'
                      ? 'text-purple-400 bg-purple-500/10 border border-purple-500/30'
                      : difficulty === 'sweat'
                      ? 'text-red-400 bg-red-500/10 border border-red-500/30'
                      : difficulty === 'smarty'
                      ? 'text-amber-400 bg-amber-500/10 border border-amber-500/30'
                      : 'text-cyan-400 bg-cyan-500/10 border border-cyan-500/30'
                  }`}
                >
                  {difficulty.toUpperCase()}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 leading-tight">
                {difficulty === 'tryhard'
                  ? 'Tryhard: actual thinking bot. Calculates multi-turn trades, coordinates transport drops & hard-counters.'
                  : difficulty === 'sweat'
                  ? 'Sweat (expert AI): lethal focus-firing, artillery standoff kiting, covers trenches & interceptors.'
                  : difficulty === 'smarty'
                  ? 'Smarty (intermediate bot AI): evaluates damage trades, triage healing, and retreats wounded units.'
                  : 'Normal (normal bot AI): basic combat reactions & structure captures.'}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-1 mt-2">
              {[
                { id: 'normal', label: 'Normal', tip: 'Normal bot AI' },
                { id: 'smarty', label: 'Smarty', tip: 'Intermediate bot AI' },
                { id: 'sweat', label: 'Sweat', tip: 'Expert AI' },
                { id: 'tryhard', label: 'Tryhard', tip: 'Actual thinking bot' },
              ].map(({ id, label, tip }) => (
                <button
                  key={id}
                  onClick={() => setDifficulty(id as BotDifficulty)}
                  title={tip}
                  className={`py-1 text-[10px] font-mono font-bold rounded border transition-colors uppercase ${
                    difficulty === id
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm'
                      : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Army Deployment Mode */}
          <div className="flex flex-col justify-between p-3 bg-[#0c1012] rounded-lg border border-[#232c32]">
            <div>
              <div className="text-xs font-bold text-slate-200 font-mono">Army Deployment</div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {isSpectate
                  ? 'Bots deploy automatically'
                  : autoDeploy
                  ? 'Auto-deploy armies & start Turn 1'
                  : 'Manual placement tile-by-tile'}
              </div>
            </div>
            <button
              onClick={() => !isSpectate && setAutoDeploy(!autoDeploy)}
              disabled={isSpectate}
              className={`mt-2 px-3 py-1.5 text-xs font-mono font-bold rounded-lg border transition-colors ${
                isSpectate || autoDeploy
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isSpectate ? 'AUTO (BOT SIM)' : autoDeploy ? 'INSTANT COMBAT' : 'MANUAL SETUP'}
            </button>
          </div>

          {/* Fog of War Toggle */}
          <div className="flex flex-col justify-between p-3 bg-[#0c1012] rounded-lg border border-[#232c32]">
            <div>
              <div className="text-xs font-bold text-slate-200 font-mono">Fog of War</div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {isSpectate
                  ? 'Spectator view reveals all tiles'
                  : 'Units reveal tiles in line of sight'}
              </div>
            </div>
            <button
              onClick={() => setFogOfWar(!fogOfWar)}
              className={`mt-2 px-3 py-1.5 text-xs font-mono font-bold rounded-lg border transition-colors ${
                !isSpectate && fogOfWar
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isSpectate ? 'REVEALED (SPECTATOR)' : fogOfWar ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>
        </div>

        {/* Map Size & Base Layout Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-[#232c32]">
          {/* Custom Map Scale */}
          <div className="p-3 bg-[#0c1012] rounded-lg border border-[#232c32] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 font-mono">Map Dimension Scale</span>
              <span className="text-[10px] font-mono text-amber-400 font-bold px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">
                {actualSize}x{actualSize} Grid
              </span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { size: 10, label: '10x10', sub: 'Compact' },
                { size: 15, label: '15x15', sub: 'Tactical' },
                { size: 20, label: '20x20', sub: 'Frontline' },
                { size: 30, label: '30x30', sub: 'Theater' },
              ].map(({ size, label, sub }) => (
                <button
                  key={size}
                  onClick={() => setCustomSize(size)}
                  className={`py-1.5 px-1 rounded-lg border text-center transition-all ${
                    actualSize === size
                      ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-sm'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white hover:border-slate-600'
                  }`}
                >
                  <div className="text-[11px] font-mono font-bold leading-tight">{label}</div>
                  <div className="text-[9px] opacity-75">{sub}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Base & HQ Layout */}
          <div className="p-3 bg-[#0c1012] rounded-lg border border-[#232c32] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200 font-mono">HQ & Base Layout</span>
              <span className="text-[10px] font-mono text-cyan-400 font-bold px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30">
                {baseLayout.toUpperCase()}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'random', label: 'Dynamic', sub: 'Asymmetric' },
                { id: 'diagonal', label: 'Diagonal', sub: 'Corners' },
                { id: 'flank', label: 'Flanks', sub: 'East/West' },
                { id: 'asymmetric', label: 'Staggered', sub: 'Off-Center' },
                { id: 'corners', label: 'Fortress', sub: '4 Corners' },
                { id: 'standard', label: 'Classic', sub: 'Opposite' },
              ].map(({ id, label, sub }) => (
                <button
                  key={id}
                  onClick={() => setBaseLayout(id as any)}
                  className={`py-1 px-1 rounded-lg border text-center transition-all ${
                    baseLayout === id
                      ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400 shadow-sm'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white hover:border-slate-600'
                  }`}
                >
                  <div className="text-[10px] font-mono font-bold leading-tight">{label}</div>
                  <div className="text-[8px] opacity-75">{sub}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Customizable Bot Skins & Liveries (Duels, Tri-Wars, Grand 4-Way Wars) */}
        <div className="p-4 bg-[#0c1012] rounded-xl border border-[#232c32] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#1f282e] pb-2.5">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-amber-400" />
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-slate-200">
                  Bot Faction Skins & Liveries
                </h3>
                <p className="text-[11px] text-slate-400">
                  Customize the visual military livery for every bot opponent in Duels, Tri-Wars, and 4-Way Wars.
                </p>
              </div>
            </div>

            {/* Quick Theme Presets */}
            <div className="flex flex-wrap items-center gap-1 text-[10px] font-mono">
              <span className="text-slate-500 mr-1 hidden md:inline">Quick Theme:</span>
              <button
                type="button"
                onClick={() =>
                  setBotSkins({
                    1: 'skin_ww2_germany',
                    2: 'skin_ww2_britain',
                    3: 'skin_imperial_japan',
                    0: 'skin_modern_usa',
                  })
                }
                className="px-2 py-0.5 rounded bg-[#182126] hover:bg-[#223038] text-amber-300 border border-[#2b3842] transition-colors"
              >
                WW2 Theater
              </button>
              <button
                type="button"
                onClick={() =>
                  setBotSkins({
                    1: 'skin_napoleonic_france',
                    2: 'skin_napoleonic_britain',
                    3: 'skin_imperial_japan',
                    0: 'skin_napoleonic_france',
                  })
                }
                className="px-2 py-0.5 rounded bg-[#182126] hover:bg-[#223038] text-blue-300 border border-[#2b3842] transition-colors"
              >
                Napoleonic
              </button>
              <button
                type="button"
                onClick={() =>
                  setBotSkins({
                    1: 'skin_girls_und_panzer',
                    2: 'skin_neko',
                    3: 'skin_cyber',
                    0: 'skin_neko',
                  })
                }
                className="px-2 py-0.5 rounded bg-[#182126] hover:bg-[#223038] text-rose-300 border border-[#2b3842] transition-colors"
              >
                Anime / Neko
              </button>
              <button
                type="button"
                onClick={() =>
                  setBotSkins({
                    1: 'skin_toy_soldiers',
                    2: 'skin_toy_soldiers',
                    3: 'skin_toy_soldiers',
                    0: 'skin_toy_soldiers',
                  })
                }
                className="px-2 py-0.5 rounded bg-[#182126] hover:bg-[#223038] text-emerald-300 border border-[#2b3842] transition-colors"
              >
                Toy Soldiers
              </button>
            </div>
          </div>

          {/* Bot Factions Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {(isSpectate
              ? Array.from({ length: currentPreset.players }, (_, i) => i)
              : Array.from({ length: currentPreset.players }, (_, i) => i).filter(
                  (f) => !currentPreset.humans.includes(f)
                )
            ).map((factionId) => {
              const activeSkinId = botSkins[factionId] || SKINS_CATALOG[factionId % SKINS_CATALOG.length]?.id;
              const skinDef = SKINS_CATALOG.find((s) => s.id === activeSkinId) || SKINS_CATALOG[0];

              return (
                <div
                  key={factionId}
                  className="p-3 rounded-lg bg-[#080b0d] border border-[#232c32] flex flex-col justify-between space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-full border border-white/20"
                        style={{ backgroundColor: FACTION_COLORS[factionId] || '#94a3b8' }}
                      />
                      <span className="text-xs font-mono font-bold text-slate-200">
                        {isSpectate ? `AI ${factionId + 1}` : `Bot ${factionId}`} ({FACTION_NAMES[factionId]?.split(' ')[0] || `Faction ${factionId + 1}`})
                      </span>
                    </div>
                    <span
                      className="text-[10px] font-mono px-1.5 py-0.5 rounded border flex items-center gap-1"
                      style={{
                        color: skinDef.accentColor,
                        borderColor: `${skinDef.accentColor}40`,
                        backgroundColor: `${skinDef.accentColor}15`,
                      }}
                    >
                      <span
                        className="w-2 h-2 rounded-full inline-block"
                        style={{ backgroundColor: skinDef.accentColor }}
                      />
                      {skinDef.name.split(' ')[0]}
                    </span>
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-slate-400 block mb-1">
                      Selected Bot Skin:
                    </label>
                    <select
                      value={activeSkinId}
                      onChange={(e) =>
                        setBotSkins((prev) => ({
                          ...prev,
                          [factionId]: e.target.value,
                        }))
                      }
                      className="w-full bg-[#11171a] border border-[#2b3842] text-slate-200 text-xs font-mono rounded px-2.5 py-1.5 focus:border-amber-400 outline-none transition-colors cursor-pointer"
                    >
                      {SKINS_CATALOG.map((skin) => (
                        <option key={skin.id} value={skin.id}>
                          {skin.name} ({skin.tagline})
                        </option>
                      ))}
                    </select>
                  </div>

                  <p className="text-[10px] text-slate-400 leading-tight italic truncate">
                    {skinDef.tagline}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Start Button */}
        <button
          onClick={handleLaunch}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/30 uppercase tracking-wider transition-all mt-4"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>
            {isSpectate
              ? 'Start Bot Simulation'
              : autoDeploy
              ? 'Instant Deploy & Start Combat'
              : 'Deploy to Sector'}
          </span>
        </button>
      </div>
    </div>
  );
};
