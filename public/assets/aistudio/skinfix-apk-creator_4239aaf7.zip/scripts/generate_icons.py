#!/usr/bin/env python3
import os
from PIL import Image, ImageDraw

def generate_frontline_icon(size, is_maskable=False):
    # Create dark slate-blue military background with gold star and crossed swords / shield
    img = Image.new("RGBA", (size, size), (11, 14, 17, 255))
    draw = ImageDraw.Draw(img)
    
    pad = int(size * 0.15) if is_maskable else int(size * 0.05)
    inner_size = size - 2 * pad
    
    # Outer shield shape
    cx = size // 2
    cy = size // 2
    
    # Gradient or solid dark shield
    shield_color = (19, 26, 30, 255)
    border_color = (245, 158, 11, 255) # Gold
    accent_blue = (56, 189, 248, 255) # Cyan
    
    # Draw Shield background
    r = int(inner_size * 0.42)
    top_y = cy - r
    mid_y = cy + int(r * 0.2)
    bot_y = cy + r
    
    shield_points = [
        (cx - r, top_y),
        (cx + r, top_y),
        (cx + r, mid_y),
        (cx, bot_y),
        (cx - r, mid_y)
    ]
    draw.polygon(shield_points, fill=shield_color, outline=border_color)
    
    # Inner tactical crosshairs
    lw = max(2, size // 100)
    draw.line([(cx, top_y + 10), (cx, bot_y - 10)], fill=(56, 189, 248, 180), width=lw)
    draw.line([(cx - r + 10, cy), (cx + r - 10, cy)], fill=(56, 189, 248, 180), width=lw)
    draw.ellipse([cx - r//3, cy - r//3, cx + r//3, cy + r//3], outline=(56, 189, 248, 220), width=lw)
    
    # Center Gold 5-pointed star
    star_r = int(r * 0.28)
    import math
    star_pts = []
    for i in range(10):
        angle = i * math.pi / 5 - math.pi / 2
        dist = star_r if i % 2 == 0 else int(star_r * 0.45)
        px = cx + int(math.cos(angle) * dist)
        py = cy + int(math.sin(angle) * dist)
        star_pts.append((px, py))
    draw.polygon(star_pts, fill=(251, 191, 36, 255), outline=(245, 158, 11, 255))
    
    return img

def main():
    os.makedirs("public", exist_ok=True)
    
    icon192 = generate_frontline_icon(192)
    icon192.save("public/pwa-192x192.png")
    print("Saved public/pwa-192x192.png")
    
    icon512 = generate_frontline_icon(512)
    icon512.save("public/pwa-512x512.png")
    print("Saved public/pwa-512x512.png")
    
    maskable512 = generate_frontline_icon(512, is_maskable=True)
    maskable512.save("public/pwa-maskable-512x512.png")
    print("Saved public/pwa-maskable-512x512.png")
    
    apple180 = generate_frontline_icon(180)
    apple180.save("public/apple-touch-icon.png")
    print("Saved public/apple-touch-icon.png")
    
    ico = generate_frontline_icon(64)
    ico.save("public/favicon.ico")
    print("Saved public/favicon.ico")

if __name__ == "__main__":
    main()
