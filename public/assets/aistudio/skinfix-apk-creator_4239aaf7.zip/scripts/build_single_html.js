import fs from 'node:fs';
import path from 'node:path';

function buildSingleHtml() {
  const distDir = path.resolve('dist');
  const distHtmlPath = path.join(distDir, 'index.html');

  if (!fs.existsSync(distHtmlPath)) {
    console.error('dist/index.html not found. Please run vite build first.');
    process.exit(1);
  }

  let html = fs.readFileSync(distHtmlPath, 'utf8');

  // Inline CSS
  const cssMatches = [...html.matchAll(/<link\s+rel="stylesheet"[^>]*href="\.?\/assets\/([^"]+)"[^>]*>/g)];
  for (const match of cssMatches) {
    const fullTag = match[0];
    const cssFileName = match[1];
    const cssFilePath = path.join(distDir, 'assets', cssFileName);
    if (fs.existsSync(cssFilePath)) {
      const cssContent = fs.readFileSync(cssFilePath, 'utf8');
      html = html.replace(fullTag, () => `<style>\n/* Inlined stylesheet: ${cssFileName} */\n${cssContent}\n</style>`);
      console.log(`Inlined CSS: ${cssFileName} (${Math.round(cssContent.length / 1024)} KB)`);
    }
  }

  // Inline JS script modules
  const scriptMatches = [...html.matchAll(/<script\s+type="module"[^>]*src="\.?\/assets\/([^"]+)"[^>]*><\/script>/g)];
  for (const match of scriptMatches) {
    const fullTag = match[0];
    const jsFileName = match[1];
    const jsFilePath = path.join(distDir, 'assets', jsFileName);
    if (fs.existsSync(jsFilePath)) {
      const jsContent = fs.readFileSync(jsFilePath, 'utf8');
      // Escape </script> if present to avoid breaking HTML parser
      const safeJsContent = jsContent.replace(/<\/script>/gi, '<\\/script>');
      html = html.replace(fullTag, () => `<script type="module">\n// Inlined script: ${jsFileName}\n${safeJsContent}\n</script>`);
      console.log(`Inlined JS: ${jsFileName} (${Math.round(jsContent.length / 1024)} KB)`);
    }
  }

  // Remove SW registration in standalone file so it can be opened via file:// or custom webview protocols
  html = html.replace(/<script\s+id="vite-plugin-pwa:register-sw"[^>]*><\/script>/g, '');
  html = html.replace(/<link\s+rel="manifest"[^>]*>/g, '');

  // Targets
  const publicOutPath = path.resolve('public', 'frontline_command_standalone.html');
  const distOutPath = path.resolve('dist', 'frontline_command_standalone.html');
  const rootOutPath = path.resolve('frontline_command_standalone.html');

  fs.writeFileSync(publicOutPath, html, 'utf8');
  fs.writeFileSync(distOutPath, html, 'utf8');
  fs.writeFileSync(rootOutPath, html, 'utf8');

  console.log(`Successfully generated standalone single-file HTML5:`);
  console.log(` - ${publicOutPath} (${Math.round(html.length / 1024)} KB)`);
  console.log(` - ${distOutPath}`);
  console.log(` - ${rootOutPath}`);
}

buildSingleHtml();
