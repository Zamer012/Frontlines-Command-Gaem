import test from 'node:test';
import assert from 'node:assert/strict';
import { GameEngine } from './engine';
import { UNIT_BLUEPRINTS, STARTER_UNITS } from '../data/units';

test('Starter units include Supplier, Engineer, Machine Gunner, Transport, and core troops', () => {
  assert.ok(STARTER_UNITS.includes('P'), 'Supplier should be in starter units');
  assert.ok(STARTER_UNITS.includes('N'), 'Engineer should be in starter units');
  assert.ok(STARTER_UNITS.includes('Z'), 'Machine Gunner should be in starter units');
  assert.ok(STARTER_UNITS.includes('AT'), 'Assault Transport should be in starter units');
  assert.ok(STARTER_UNITS.includes('R'), 'Riflemen should be in starter units');
  assert.ok(STARTER_UNITS.includes('B'), 'Battle Tank should be in starter units');
});

test('GameEngine initializes 15x15 board with 2 factions and HQs', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 15,
    playersCount: 2,
    humanFactions: [0],
  });

  assert.equal(engine.N, 15);
  assert.equal(engine.NP, 2);
  assert.equal(engine.alive[0], true);
  assert.equal(engine.alive[1], true);

  const playerHq = engine.U.find((u) => u.t === 'H' && u.o === 0);
  const enemyHq = engine.U.find((u) => u.t === 'H' && u.o === 1);
  assert.ok(playerHq, 'Player HQ must exist');
  assert.ok(enemyHq, 'Enemy HQ must exist');
});

test('Carry unit logic: Transport can embark adjacent friendly infantry and eject safely', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
  });

  const transport = engine.addUnit('AT', 0, 3, 3);
  const infantry = engine.addUnit('R', 0, 3, 4);

  assert.equal(engine.U.includes(infantry), true);
  assert.equal(transport.cargo, null);

  // Load infantry
  transport.cargo = infantry;
  engine.U = engine.U.filter((u) => u !== infantry);

  assert.equal(engine.U.includes(infantry), false);
  assert.equal(transport.cargo.t, 'R');

  // Unload cargo
  const unloadTarget = { x: 3, y: 4 };
  const cargo = transport.cargo;
  cargo.x = cargo.rx = unloadTarget.x;
  cargo.y = cargo.ry = unloadTarget.y;
  engine.U.push(cargo);
  transport.cargo = null;

  assert.equal(engine.U.includes(cargo), true);
  assert.equal(cargo.x, 3);
  assert.equal(cargo.y, 4);
});

test('Healer logic: Field Medic restores HP to damaged infantry', () => {
  const engine = new GameEngine();
  engine.initMatch({
    mapSize: 10,
    playersCount: 2,
    humanFactions: [0],
  });

  const wounded = engine.addUnit('R', 0, 2, 2);
  wounded.hp = 1; // damaged
  assert.equal(wounded.hp, 1);

  // Field triage restores 3 HP up to maxHp
  const healAmount = 3;
  wounded.hp = Math.min(wounded.maxHp, wounded.hp + healAmount);
  assert.equal(wounded.hp, wounded.maxHp);
});

test('Mobile Factory Spawner: can construct units on the field', () => {
  const bp = UNIT_BLUEPRINTS.FC;
  assert.ok(bp, 'FC blueprint exists');
  assert.equal(bp.isSpawner, true);
  assert.equal(bp.c, 42, 'Factory Crawler has high cost');
  assert.ok(bp.ab.some((ab) => ab.f.includes('sp')), 'Has spawner ability flag');
});
